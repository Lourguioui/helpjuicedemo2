/**
 * Component Modules/Components
 */
import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import {
	addDays,
	areIntervalsOverlapping,
	differenceInCalendarDays,
	eachDayOfInterval,
	endOfDay,
	startOfDay,
	startOfToday,
	subDays,
} from "date-fns";
import { CommonService } from "../common/common.service";
import { CalendarSettings } from "../common/models";
/**
 * Component Decorator
 */
@Component({
	selector: "app-calendar",
	templateUrl: "./calendar.component.html",
	styleUrls: ["./calendar.component.css"],
})
/**
 * Component Class
 */
export class CalendarComponent implements OnInit {
	/**
	 * Component Properties
	 */
	loading: boolean = false;
	dragging: boolean = false;
	scrollbar: boolean = false;
	mousedown: boolean = false;
	days: string[] = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];
	months: string[] = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
	dates: Date[] = [];
	start: Date = startOfToday();
	today: Date = startOfToday();
	lastVisitedDate: Date;
	lastVisitedCell: any;
	dragStarted: Date;
	dragEnded: Date;
	targetRow: any;
	data: any[] = [];
	calendarSettings: CalendarSettings = new CalendarSettings();
	activeEvent: Event;
	/**
	 * Component Constructor
	 * @param cdr {ChangeDetectorRef}
	 */
	constructor(public common: CommonService) {
		this.sliderColumnFormatter = this.sliderColumnFormatter.bind(this);
		this.sliderRowFormatter = this.sliderRowFormatter.bind(this);
	}
	/*************************************************************
	 * COMPONENT LIFECYCLE HOOKS
	 *************************************************************/
	/**
	 * Component On Init
	 */
	async ngOnInit() {
		this.setCalendarSettings("restore");
		this.renderCalendar();
	}
	/*************************************************************
	 * RENDER CALENDAR METHODS
	 *************************************************************/
	/**
	 * Render Calendar
	 */
	async renderCalendar() {
		await this.getData();
		this.resizeCalendar();
		this.calculateDates();
		setTimeout(() => {
			let calendarWrapper = document.getElementById("calendar-body");
			let hasVerticalScrollbar = calendarWrapper.scrollHeight > calendarWrapper.clientHeight;
			if (hasVerticalScrollbar) {
				this.scrollbar = true;
			} else {
				this.scrollbar = false;
			}
		}, 300);
	}
	/**
	 * Render draggable
	 * @param record {any}
	 */
	renderDraggable(record: any) {
		let interval = {
			start: startOfDay(new Date(record.startDate)),
			end: startOfDay(new Date(record.endDate)),
		};
		let calendarInterval = {
			start: this.start,
			end: startOfDay(addDays(this.start, this.calendarSettings.columns)),
		};
		let display = "none";
		let dayCell = document.querySelector(".day-cell");
		let cellWidth = dayCell.getBoundingClientRect().width;
		let cellHeight = dayCell.getBoundingClientRect().height;
		if (areIntervalsOverlapping(interval, calendarInterval, { inclusive: true })) {
			display = "flex";
		}
		let start = differenceInCalendarDays(interval.start, calendarInterval.start);
		if (start < 0) {
			start = 0;
		}
		let length = 0;
		if (calendarInterval.start > interval.start) {
			length = differenceInCalendarDays(interval.end, calendarInterval.start);
		} else {
			length = differenceInCalendarDays(interval.end, interval.start);
		}
		let left: string;
		if (start === 0) {
			left = `${0}px`;
		} else {
			left = `${start * cellWidth}px`;
		}
		return {
			left: left,
			width: `${length * cellWidth + cellWidth}px`,
			height: `${cellHeight}px`,
			display: `${display}`,
		};
	}
	/**
	 * Render table cell
	 */
	renderCell() {
		return {
			height: `calc(68vh/${this.calendarSettings.rows})`,
			"max-height": `calc(68vh/${this.calendarSettings.rows})`,
			"min-height": `calc(68vh/${this.calendarSettings.rows})`,
		};
	}
	/**
	 * Resize calendar
	 */
	resizeCalendar() {
		let width = window.innerWidth;
		if (width < 1800 && this.calendarSettings.columns > 14) {
			this.calendarSettings.columns = 14;
			this.calendarSettings.maxColumns = 14;
		} else if (width >= 1800 && this.calendarSettings.maxColumns < 30) {
			this.calendarSettings.columns = 30;
			this.calendarSettings.maxColumns = 30;
		}
	}
	/**
	 * Calculate dates
	 */
	calculateDates() {
		let start = startOfDay(new Date(this.start));
		let interval = {
			start: start,
			end: startOfDay(addDays(start, this.calendarSettings.columns)),
		};
		this.dates = eachDayOfInterval(interval);
	}
	/**
	 * Window on resize
	 */
	windowOnResize(): void {
		this.renderCalendar();
	}
	/*************************************************************
	 * ON CHANGE/CLICK
	 *************************************************************/
	/**
	 * Number of columns on change
	 * @param cells {number}
	 */
	columnsOnChange(columns: number) {
		this.setCalendarSettings("save");
		this.renderCalendar();
	}
	/**
	 * Number of rows on change
	 * @param cells {number}
	 */
	rowsOnChange(rows: number) {
		this.setCalendarSettings("save");
		this.renderCalendar();
	}
	/**
	 * Date on change
	 * @param date {Date}
	 */
	dateOnChange(date: Date) {
		this.renderCalendar();
	}
	/**
	 * Cell on mouse down
	 * @param event {any}
	 * @param date {Date}
	 * @param row {any}
	 */
	cellOnMouseDown(event: any, date: Date, row: any) {
		date = startOfDay(date);
		this.mousedown = true;
		this.targetRow = row;
		this.dragStarted = date;
		event.target.classList.add("selected");
	}
	/**
	 * Cell on mouse up
	 * @param event {any}
	 * @param date {Date}
	 * @param row {any}
	 */
	cellOnMouseUp(event: any, date: Date, row: any) {
		date = startOfDay(date);
		if (this.mousedown) {
			this.mousedown = false;
			this.dragEnded = date;
			let selectionObject = {
				row: this.targetRow,
				start: this.dragStarted,
				end: this.dragEnded,
			};
		}
	}
	/**
	 * Cell on mouse enter
	 * @param event {any}
	 * @param date {Date}
	 * @param row {any}
	 */
	cellOnMouseEnter(event: any, date: Date, row: any) {
		if (this.mousedown) {
			if (this.lastVisitedDate && date < this.lastVisitedDate) {
				this.lastVisitedCell.classList.remove("selected");
			} else {
				this.lastVisitedCell.classList.add("selected");
			}
		} else {
			return;
		}
	}
	/**
	 * Cell on mouse leave
	 * @param event {any}
	 * @param date {Date}
	 * @param row {any}
	 */
	cellOnMouseLeave(event: any, date: Date, row: any) {
		if (this.mousedown) {
			if (row.id === this.targetRow.id) {
				this.lastVisitedDate = date;
				this.lastVisitedCell = event.target;
			} else {
				this.resetSelectedCells();
			}
		} else {
			return;
		}
	}
	/**
	 * Reset selected cells
	 */
	resetSelectedCells() {
		this.mousedown = false;
		this.lastVisitedCell = undefined;
		this.lastVisitedDate = undefined;
		this.targetRow = undefined;
		this.dragStarted = undefined;
		this.dragEnded = undefined;
		document.querySelectorAll(".day-cell").forEach((elem) => {
			elem.classList.remove("selected");
		});
	}
	/*************************************************************
	 * ACTION METHODS
	 *************************************************************/
	/**
	 * On draggable moved
	 * @param event
	 */
	async onDraggableMoved(event: any) {
		this.dragging = true;
	}
	/**
	 * On draggable released
	 * @param event {any}
	 * @param data {any}
	 */
	async onDraggableReleased(event: any, data: any) {
		try {
			let draggedElement = event.source.element.nativeElement;
			draggedElement.hidden = true;
			let elementBelow = document.elementFromPoint(
				event.source._dragRef._lastKnownPointerPosition.x,
				event.source._dragRef._lastKnownPointerPosition.y
			);
			draggedElement.hidden = false;
			if (!elementBelow) {
				return event.source._dragRef.reset();
			}
			let closestDroppable = elementBelow.closest(".droppable");
			if (closestDroppable) {
				let droppableId = closestDroppable.getAttribute("data");
				let droppableData = this.data.find((record) => record.id == droppableId);
				//Do something after drag released
				this.dragging = false;
			} else {
				return event.source._dragRef.reset();
			}
		} catch (err) {
			this.common.alert("error", this.common.translate("Error moving draggable"));
		}
	}
	/**
	 * Go to today
	 */
	goToToday(): void {
		this.start = startOfToday();
		this.renderCalendar();
	}
	/**
	 * Next
	 * @param days {number}
	 */
	next(days: number): void {
		this.start = startOfDay(addDays(this.start, days));
		this.renderCalendar();
	}
	/**
	 * Previous
	 * @param days {number}
	 */
	previous(days: number): void {
		this.start = startOfDay(subDays(this.start, days));
		this.renderCalendar();
	}
	/**
	 * Open calendar settings
	 */
	openCalendarSettings() {
		this.common.toggleModal("calendarSettings");
	}
	/**
	 * Get day name
	 * @param date {Date}
	 */
	getDayName(date: Date): string {
		return this.days[date.getUTCDay()];
	}
	/**
	 * Get month name
	 * @param date {Date}
	 */
	getMonthName(date: Date): string {
		return this.months[date.getMonth()];
	}
	/**
	 * Format slider label
	 */
	formatSliderLabel(value: number) {
		return value;
	}
	/**
	 * Set calendar settings
	 */
	setCalendarSettings(action: string) {
		try {
			let calendarSettings: any;
			calendarSettings = localStorage.getItem("calendar-settings");
			if (!calendarSettings) {
				calendarSettings = {
					rows: this.calendarSettings.rows,
					columns: this.calendarSettings.columns,
				};
				localStorage.setItem("calendar-settings", JSON.stringify(calendarSettings));
			} else {
				calendarSettings = JSON.parse(calendarSettings);
			}
			if (action === "save") {
				calendarSettings.rows = this.calendarSettings.rows;
				calendarSettings.columns = this.calendarSettings.columns;
				localStorage.setItem("calendar-settings", JSON.stringify(calendarSettings));
			} else if (action === "restore") {
				this.calendarSettings.rows = calendarSettings.rows;
				this.calendarSettings.columns = calendarSettings.columns;
			}
		} catch (err) {
			this.common.alert("error", this.common.translate("Unexpected Error!"));
		}
	}
	/**
	 * Slider column formatter
	 */
	sliderColumnFormatter(value: number): string {
		return `${value} ${this.common.translate("Columns")}`;
	}
	/**
	 * Slider row formatter
	 */
	sliderRowFormatter(value: number): string {
		return `${value} ${this.common.translate("Rows")}`;
	}
	/**
	 * Draggable on click
	 * @param data {any}
	 */
	draggableOnClick(data: any) {
		if (!this.dragging) {
			this.activeEvent = data;
			this.common.toggleModal("eventDetails");
		}
	}
	/**
	 * Get data
	 */
	async getData() {
		this.loading = true;
		let params = {
			start: this.start,
			end: startOfDay(addDays(this.start, this.calendarSettings.columns)),
		};
		let res = await this.common.post(`/calendar/get-events`, params);
		if (res) {
			this.data = res;
		}
		this.loading = false;
	}
	/**
	 * Toggle day view
	 */
	toggleDayView() {
		this.common.alert("info", "Under Development");
	}
}
